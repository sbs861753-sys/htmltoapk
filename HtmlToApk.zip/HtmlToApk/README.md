# HTML to APK

An Android app that turns a website (HTML, CSS, JavaScript) into an installable Android app,
**fully offline, on the phone**.

## How to use it (on the phone)

1. Put your website in a folder with `index.html` as the main page, then zip the folder.
   (A single `.html` file also works.)
2. Open **HTML to APK** and tap **Choose .zip or .html file**.
3. Type an app name. Optionally pick an icon (any PNG/JPG).
4. Tap **Build APK**, then **Install**.
   The first time, Android asks you to allow "Install unknown apps" for HTML to APK. Allow it, come back, tap Install again.
5. **Save APK to...** keeps a copy you can share.

Tips
- Each app needs its own **package name**. To update an app you already installed, build it again with the same package name.
- Links to other websites open in the phone's browser. Your own pages open inside the app.
- All apps are signed with a key created on first use and stored inside HTML to APK.
  If you uninstall HTML to APK, that key is lost and you cannot update apps made before.

## How to get the HTML to APK app itself (one time)

You need to build this project once. It needs internet only for that step.

### Option A: Android Studio (on a computer)
1. Install Android Studio.
2. **File > Open** and choose this `HtmlToApk` folder. Wait for "Sync" to finish.
   (If it offers to upgrade Gradle or the Android plugin, say yes.)
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The file is `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it.

### Option B: GitHub Actions (no computer setup)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder (including the hidden `.github` folder).
3. Open the **Actions** tab, run **Build APK**, then download `html-to-apk` from the finished run.

## What is inside

| Folder | What it is |
|---|---|
| `template/` | A blank WebView app. It shows `assets/www/index.html` and serves every file from there offline. |
| `app/` | The builder. It contains the template APK and does the work. |
| `app/.../ApkBuilder.java` | Unpack template, change name, swap icon, add your files, sign. |
| `app/.../AxmlPatcher.java` | Edits the compiled `AndroidManifest.xml` (name and package) without any tools. |
| `app/.../AlignedZipWriter.java` | Writes the APK zip the way Android 11+ requires. |
| `app/.../SigningKey.java` | Creates and stores the signing key. |

Build order: Gradle builds `template` first and copies its APK into `app/src/main/assets/template.apk`,
then builds `app`.

## Not included yet

- **Java code.** Compiling Java on the phone needs a bundled compiler (ECJ + D8) and `android.jar`.
  Planned as version 2.
- Changing version number, permissions, or splash screen per app.
- Publishing on Google Play (needs an AAB and your own upload key).
