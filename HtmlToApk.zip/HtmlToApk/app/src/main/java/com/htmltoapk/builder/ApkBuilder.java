package com.htmltoapk.builder;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.android.apksig.ApkSigner;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Turns a zip (or single .html file) into an installable APK, completely offline.
 *
 * 1. Takes the blank template APK that ships inside this app (assets/template.apk).
 * 2. Rewrites its manifest with the new app name and package name.
 * 3. Optionally swaps the launcher icon.
 * 4. Puts the user's web files into assets/www.
 * 5. Signs the result with a key stored on this device.
 */
final class ApkBuilder {

    // These two texts exist in the template's manifest and are replaced.
    static final String TEMPLATE_PACKAGE = "com.template.webview";
    static final String TEMPLATE_LABEL = "WebAppTemplateLabel";

    interface Progress {
        void step(String message);
    }

    private ApkBuilder() {
    }

    static File build(Context ctx, Uri project, Uri icon, String appName, String packageName,
                      Progress progress) throws Exception {
        File work = new File(ctx.getCacheDir(), "work");
        deleteRecursive(work);
        if (!work.mkdirs()) {
            throw new IOException("Cannot create a work folder");
        }
        File outDir = new File(ctx.getCacheDir(), "out");
        if (!outDir.exists() && !outDir.mkdirs()) {
            throw new IOException("Cannot create the output folder");
        }

        progress.step("Reading your files...");
        File input = new File(work, "input.bin");
        try (InputStream in = ctx.getContentResolver().openInputStream(project)) {
            if (in == null) {
                throw new IOException("Cannot open the file you picked");
            }
            copyToFile(in, input);
        }

        Bitmap iconBitmap = null;
        if (icon != null) {
            try (InputStream in = ctx.getContentResolver().openInputStream(icon)) {
                iconBitmap = in == null ? null : BitmapFactory.decodeStream(in);
            }
            if (iconBitmap == null) {
                throw new IOException("The icon image could not be read");
            }
            iconBitmap = centerSquare(iconBitmap);
        }

        File template = new File(work, "template.apk");
        try (InputStream in = ctx.getAssets().open("template.apk")) {
            copyToFile(in, template);
        } catch (FileNotFoundException e) {
            throw new IOException("template.apk is missing inside the app. "
                    + "Build the project with Gradle so the 'template' module is built first.");
        }

        progress.step("Building the app...");
        File unsigned = new File(work, "unsigned.apk");
        int webFiles;
        boolean iconReplaced = false;
        try (ZipFile templateZip = new ZipFile(template);
             AlignedZipWriter writer = new AlignedZipWriter(new FileOutputStream(unsigned))) {

            Enumeration<? extends ZipEntry> entries = templateZip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement();
                String name = e.getName();
                if (e.isDirectory() || name.startsWith("META-INF/") || name.startsWith("assets/www/")) {
                    continue; // old signature and the template's placeholder page are dropped
                }
                byte[] data = readAll(templateZip.getInputStream(e));

                if (name.equals("AndroidManifest.xml")) {
                    Map<String, String> changes = new HashMap<>();
                    changes.put(TEMPLATE_PACKAGE, packageName);
                    changes.put(TEMPLATE_LABEL, appName);
                    writer.addDeflated(name, AxmlPatcher.replaceStrings(data, changes));
                } else if (name.equals("resources.arsc")) {
                    writer.addStoredAligned(name, data, 4); // required by Android 11+
                } else if (iconBitmap != null && isLauncherIcon(name)) {
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
                    int size = bounds.outWidth > 0 ? bounds.outWidth : 192;
                    Bitmap scaled = Bitmap.createScaledBitmap(iconBitmap, size, size, true);
                    ByteArrayOutputStream png = new ByteArrayOutputStream();
                    scaled.compress(Bitmap.CompressFormat.PNG, 100, png);
                    writer.addDeflated(name, png.toByteArray());
                    iconReplaced = true;
                } else {
                    writer.addDeflated(name, data);
                }
            }

            progress.step("Adding your web files...");
            webFiles = addWebFiles(input, writer);
        }

        if (iconBitmap != null && !iconReplaced) {
            progress.step("Note: the icon could not be replaced, the default icon is used.");
        }

        progress.step("Signing the app...");
        SigningKey key = SigningKey.loadOrCreate(new File(ctx.getFilesDir(), "signing"));
        File signed = new File(outDir, packageName + ".apk");
        if (signed.exists() && !signed.delete()) {
            throw new IOException("Cannot replace the previous build");
        }
        ApkSigner.SignerConfig signer = new ApkSigner.SignerConfig.Builder(
                "webapp", key.privateKey, Collections.singletonList(key.certificate)).build();
        new ApkSigner.Builder(Collections.singletonList(signer))
                .setInputApk(unsigned)
                .setOutputApk(signed)
                .setMinSdkVersion(24)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .build()
                .sign();

        deleteRecursive(work);
        progress.step("Done. " + webFiles + " files, " + (signed.length() / 1024) + " KB.");
        return signed;
    }

    // ---- web files ----

    /** Copies the user's files into assets/www and returns how many were added. */
    private static int addWebFiles(File input, AlignedZipWriter writer) throws IOException {
        if (!looksLikeZip(input)) {
            try (InputStream in = new FileInputStream(input)) {
                writer.addDeflated("assets/www/index.html", in);
            }
            return 1;
        }

        try (ZipFile zip = new ZipFile(input)) {
            List<ZipEntry> files = new ArrayList<>();
            List<String> names = new ArrayList<>();
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = e.getName().replace('\\', '/');
                if (e.isDirectory() || !isSafeName(name) || isJunk(name)) {
                    continue;
                }
                files.add(e);
                names.add(name);
            }

            // Find the main page: the shallowest index.html (zip may contain one top folder).
            String main = null;
            int bestDepth = Integer.MAX_VALUE;
            for (String n : names) {
                if (n.equals("index.html") || n.endsWith("/index.html")) {
                    int depth = depth(n);
                    if (depth < bestDepth) {
                        bestDepth = depth;
                        main = n;
                    }
                }
            }

            String prefix;
            String renameToIndex = null;
            if (main != null) {
                prefix = main.substring(0, main.length() - "index.html".length());
            } else {
                // No index.html: accept a single .html file and use it as the main page.
                String only = null;
                int best = Integer.MAX_VALUE;
                int ties = 0;
                for (String n : names) {
                    String lower = n.toLowerCase();
                    if (lower.endsWith(".html") || lower.endsWith(".htm")) {
                        int d = depth(n);
                        if (d < best) {
                            best = d;
                            only = n;
                            ties = 1;
                        } else if (d == best) {
                            ties++;
                        }
                    }
                }
                if (only == null) {
                    throw new IOException("No index.html found in the zip. "
                            + "Your main page must be called index.html.");
                }
                if (ties > 1) {
                    throw new IOException("The zip has several .html files but no index.html. "
                            + "Rename your main page to index.html.");
                }
                prefix = only.substring(0, only.lastIndexOf('/') + 1);
                renameToIndex = only;
            }

            Set<String> used = new HashSet<>();
            int count = 0;
            for (int i = 0; i < files.size(); i++) {
                String name = names.get(i);
                if (!name.startsWith(prefix)) {
                    continue;
                }
                String relative = name.substring(prefix.length());
                if (name.equals(renameToIndex)) {
                    relative = "index.html";
                }
                if (relative.isEmpty()) {
                    continue;
                }
                String target = "assets/www/" + relative;
                if (!used.add(target)) {
                    continue;
                }
                try (InputStream in = zip.getInputStream(files.get(i))) {
                    writer.addDeflated(target, in);
                }
                count++;
            }
            return count;
        }
    }

    private static boolean looksLikeZip(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            return in.read() == 'P' && in.read() == 'K';
        }
    }

    private static boolean isSafeName(String name) {
        if (name.isEmpty() || name.startsWith("/")) {
            return false;
        }
        for (String part : name.split("/")) {
            if (part.equals("..")) {
                return false;
            }
        }
        return true;
    }

    private static boolean isJunk(String name) {
        return name.startsWith("__MACOSX/") || name.endsWith(".DS_Store") || name.endsWith("Thumbs.db");
    }

    private static int depth(String name) {
        int d = 0;
        for (int i = 0; i < name.length(); i++) {
            if (name.charAt(i) == '/') {
                d++;
            }
        }
        return d;
    }

    // ---- icon ----

    private static boolean isLauncherIcon(String entryName) {
        return entryName.startsWith("res/") && entryName.endsWith(".png")
                && entryName.contains("ic_launcher");
    }

    private static Bitmap centerSquare(Bitmap src) {
        int side = Math.min(src.getWidth(), src.getHeight());
        int x = (src.getWidth() - side) / 2;
        int y = (src.getHeight() - side) / 2;
        return Bitmap.createBitmap(src, x, y, side, side);
    }

    // ---- small helpers ----

    private static byte[] readAll(InputStream in) throws IOException {
        try (InputStream src = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[1 << 14];
            int n;
            while ((n = src.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    private static void copyToFile(InputStream in, File target) throws IOException {
        try (OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
        }
    }

    static void deleteRecursive(File f) {
        if (f == null || !f.exists()) {
            return;
        }
        File[] children = f.listFiles();
        if (children != null) {
            for (File c : children) {
                deleteRecursive(c);
            }
        }
        // ignore the result, leftover cache files are harmless
        f.delete();
    }
}
