package com.htmltoapk.builder;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One screen: pick files, choose a name, press Build, install the result. */
public class MainActivity extends Activity {

    private static final int REQ_PROJECT = 1;
    private static final int REQ_ICON = 2;
    private static final int REQ_SAVE = 3;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private Uri projectUri;
    private Uri iconUri;
    private File builtApk;

    private TextView projectLabel;
    private EditText nameField;
    private EditText packageField;
    private ImageView iconPreview;
    private Button chooseProjectBtn;
    private Button chooseIconBtn;
    private Button buildBtn;
    private Button installBtn;
    private Button saveBtn;
    private TextView logView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(32));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("HTML to APK");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Turn a website (HTML, CSS, JavaScript) into an Android app. "
                + "Everything happens on this phone, no internet needed.");
        intro.setPadding(0, dp(6), 0, dp(12));
        root.addView(intro);

        root.addView(sectionLabel("1. Your website"));
        chooseProjectBtn = new Button(this);
        chooseProjectBtn.setText("Choose .zip or .html file");
        chooseProjectBtn.setOnClickListener(v -> pick("*/*", REQ_PROJECT));
        root.addView(chooseProjectBtn);
        projectLabel = new TextView(this);
        projectLabel.setText("Nothing chosen yet. A zip must contain index.html.");
        root.addView(projectLabel);

        root.addView(sectionLabel("2. App name"));
        nameField = new EditText(this);
        nameField.setHint("My App");
        nameField.setSingleLine(true);
        root.addView(nameField);

        root.addView(sectionLabel("3. Package name"));
        packageField = new EditText(this);
        packageField.setSingleLine(true);
        packageField.setText("com.webapp.app" + randomLetters(5));
        root.addView(packageField);
        TextView packageHint = new TextView(this);
        packageHint.setText("Must be different for every app. Lowercase letters, numbers, dots. "
                + "Keep the same one to update an app you already installed.");
        packageHint.setTextSize(12);
        root.addView(packageHint);

        root.addView(sectionLabel("4. Icon (optional)"));
        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setOrientation(LinearLayout.HORIZONTAL);
        chooseIconBtn = new Button(this);
        chooseIconBtn.setText("Choose icon image");
        chooseIconBtn.setOnClickListener(v -> pick("image/*", REQ_ICON));
        iconRow.addView(chooseIconBtn);
        iconPreview = new ImageView(this);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(56), dp(56));
        ip.leftMargin = dp(12);
        iconPreview.setLayoutParams(ip);
        iconRow.addView(iconPreview);
        root.addView(iconRow);

        buildBtn = new Button(this);
        buildBtn.setText("Build APK");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(20);
        buildBtn.setLayoutParams(bp);
        buildBtn.setOnClickListener(v -> startBuild());
        root.addView(buildBtn);

        logView = new TextView(this);
        logView.setPadding(0, dp(12), 0, dp(8));
        logView.setTextIsSelectable(true);
        root.addView(logView);

        LinearLayout resultRow = new LinearLayout(this);
        resultRow.setOrientation(LinearLayout.HORIZONTAL);
        installBtn = new Button(this);
        installBtn.setText("Install");
        installBtn.setVisibility(View.GONE);
        installBtn.setOnClickListener(v -> install());
        resultRow.addView(installBtn);
        saveBtn = new Button(this);
        saveBtn.setText("Save APK to...");
        saveBtn.setVisibility(View.GONE);
        saveBtn.setOnClickListener(v -> chooseSaveLocation());
        resultRow.addView(saveBtn);
        root.addView(resultRow);
    }

    // ---- picking files ----

    private void pick(String mime, int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        startActivityForResult(i, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_PROJECT) {
            projectUri = uri;
            String name = displayName(uri);
            projectLabel.setText("Chosen: " + name);
            if (nameField.getText().toString().trim().isEmpty()) {
                int dot = name.lastIndexOf('.');
                nameField.setText(dot > 0 ? name.substring(0, dot) : name);
            }
        } else if (requestCode == REQ_ICON) {
            iconUri = uri;
            try {
                iconPreview.setImageURI(uri);
            } catch (Exception ignored) {
                // preview is optional
            }
        } else if (requestCode == REQ_SAVE) {
            saveTo(uri);
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (col >= 0 && c.getString(col) != null) {
                    return c.getString(col);
                }
            }
        } catch (Exception ignored) {
            // fall through
        }
        return "selected file";
    }

    // ---- building ----

    private void startBuild() {
        final String appName = nameField.getText().toString().trim();
        final String pkg = packageField.getText().toString().trim();

        if (projectUri == null) {
            toast("Choose your .zip or .html file first");
            return;
        }
        if (appName.isEmpty()) {
            toast("Type a name for your app");
            return;
        }
        if (appName.length() > 60) {
            toast("The app name is too long");
            return;
        }
        if (!pkg.matches("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+")) {
            toast("Package name looks like com.mycompany.myapp (lowercase, with dots)");
            return;
        }

        setBusy(true);
        logView.setText("");
        installBtn.setVisibility(View.GONE);
        saveBtn.setVisibility(View.GONE);
        builtApk = null;

        final Uri project = projectUri;
        final Uri icon = iconUri;
        executor.execute(() -> {
            try {
                final File apk = ApkBuilder.build(this, project, icon, appName, pkg,
                        message -> ui.post(() -> appendLog(message)));
                ui.post(() -> {
                    builtApk = apk;
                    installBtn.setVisibility(View.VISIBLE);
                    saveBtn.setVisibility(View.VISIBLE);
                    setBusy(false);
                });
            } catch (Throwable t) {
                final String message = t.getMessage() != null ? t.getMessage() : t.toString();
                ui.post(() -> {
                    appendLog("Failed: " + message);
                    setBusy(false);
                });
            }
        });
    }

    private void setBusy(boolean busy) {
        buildBtn.setEnabled(!busy);
        chooseProjectBtn.setEnabled(!busy);
        chooseIconBtn.setEnabled(!busy);
        buildBtn.setText(busy ? "Building..." : "Build APK");
    }

    private void appendLog(String line) {
        CharSequence old = logView.getText();
        logView.setText(old.length() == 0 ? line : old + "\n" + line);
    }

    // ---- installing / saving ----

    private void install() {
        if (builtApk == null || !builtApk.exists()) {
            toast("Build the app first");
            return;
        }
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            toast("Allow \"Install unknown apps\" for HTML to APK, then press Install again");
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", builtApk);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Could not open the installer: " + e.getMessage());
        }
    }

    private void chooseSaveLocation() {
        if (builtApk == null) {
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_TITLE, builtApk.getName());
        startActivityForResult(i, REQ_SAVE);
    }

    private void saveTo(final Uri target) {
        final File source = builtApk;
        if (source == null) {
            return;
        }
        executor.execute(() -> {
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(target)) {
                if (out == null) {
                    throw new java.io.IOException("Cannot write to that location");
                }
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
                ui.post(() -> toast("APK saved"));
            } catch (Exception e) {
                ui.post(() -> toast("Could not save: " + e.getMessage()));
            }
        });
    }

    // ---- small helpers ----

    private TextView sectionLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(18), 0, dp(4));
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static String randomLetters(int n) {
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append((char) ('a' + r.nextInt(26)));
        }
        return sb.toString();
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
