# HTML to APK

An Android app that turns a website (HTML, CSS, JavaScript) into an installable Android app,
**fully offline, on the phone**.

## How to use it (on the phone)

1. Put your website in a folder with `index.html` as the main page, then zip the folder.
   (A single `.html` file also works.)
2. Open **HTML to APK** and tap **Choose .zip or .html file**.
3. Type an app name (the package name fills in by itself). Optionally pick an icon (any PNG/JPG).
4. Choose the settings you want (see below).
5. Tap **Build APK**, then **Install**.
   The first time, Android asks you to allow "Install unknown apps" for HTML to APK. Allow it, come back, tap Install again.
6. **Save APK** keeps a copy, **Share** sends it to someone.

### App settings

| Setting | What it does |
|---|---|
| Version | The version name shown in Android's app info. |
| Full screen | Hides the status bar and the navigation buttons. |
| Keep screen on | The screen does not turn off while the app is open. |
| Pull down to refresh | Dragging down from the top of the page reloads it. |
| Screen rotation | Auto, always portrait, or always landscape. |
| Status bar color | Pick one of 7 colors, or keep the default. |

### Checks before building

HTML to APK looks at your website first and tells you about:
- a zip that is damaged, empty, too big (limit 300 MB), a RAR/7z file, or without `index.html`
- images, style sheets, scripts or pages that your HTML/CSS refer to but that are not in the zip
  (including capital/small letter mistakes: `Logo.PNG` vs `logo.png`)
- files loaded from the internet (CDN links), which will not work offline
- paths that point to your computer (`C:\...`, `file:///...`)
- a main page without the `viewport` tag (it would look tiny on a phone)

Warnings never stop the build. Real problems stop it with a message that says what to fix.

Tips
- Each app needs its own **package name**. To update an app you already installed, build it again with the same package name.
- Links to other websites open in the phone's browser. Your own pages open inside the app.
- All apps are signed with a key created on first use and stored inside HTML to APK.
  If you uninstall HTML to APK, that key is lost and you cannot update apps made before.

## How to get the HTML to APK app itself (one time)

You need to build this project once. It needs internet only for that step.

### Option A: GitHub Actions (works from a phone)
1. Create a free GitHub account and a new repository.
2. Upload `HtmlToApk.zip` as it is (do not unzip it).
3. **Add file > Create new file**, name it `.github/workflows/build.yml` and paste the recipe
   (the `build.yml` file that came with the zip). It unzips the project and builds it.
4. Open the **Actions** tab, wait for the green tick, open the run and download `html-to-apk`
   from **Artifacts**. Unzip it and install `app-debug.apk`.

To update later, upload the new `HtmlToApk.zip` with the same name. The build starts by itself.

### Option B: Android Studio (on a computer)
1. Install Android Studio.
2. **File > Open** and choose this `HtmlToApk` folder. Wait for "Sync" to finish.
   (If it offers to upgrade Gradle or the Android plugin, say yes.)
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The file is `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it.

## What is inside

| Folder | What it is |
|---|---|
| `template/` | A blank WebView app. It serves every file from `assets/www` offline and reads its settings from `assets/config.json`. |
| `app/` | The builder. It contains the template APK and does the work. |
| `app/.../MainActivity.java` | The screen. |
| `app/.../ApkBuilder.java` | Unpack template, change name/package/version, swap icon, add your files and settings, sign, verify. |
| `app/.../ProjectScanner.java` | Checks the website and finds problems before building. |
| `app/.../BuildOptions.java` | The choices made on the screen, and their checks. |
| `app/.../BuildException.java` | Errors written in plain words. |
| `app/.../AxmlPatcher.java` | Edits the compiled `AndroidManifest.xml` (name, package, version) without any tools. |
| `app/.../AlignedZipWriter.java` | Writes the APK zip the way Android 11+ requires. |
| `app/.../SigningKey.java` | Creates and stores the signing key. |

Build order: Gradle builds `template` first and copies its APK into `app/src/main/assets/template.apk`,
then builds `app`.

## Not included yet

- **Java code.** Compiling Java on the phone needs a bundled compiler (ECJ + D8) and `android.jar`.
  Planned as version 2.
- Extra permissions per app (camera, location, notifications), splash screen, Bengali menu text.
- Publishing on Google Play (needs an AAB and your own upload key).
