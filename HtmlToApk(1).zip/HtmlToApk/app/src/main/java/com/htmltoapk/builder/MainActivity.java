package com.htmltoapk.builder;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One screen: pick your website, name the app, choose settings, press Build, install the result. */
public class MainActivity extends Activity {

    private static final int REQ_PROJECT = 1;
    private static final int REQ_ICON = 2;
    private static final int REQ_SAVE = 3;

    private static final int PRIMARY = 0xFFE65100;
    private static final int BG = 0xFFF4F1EE;
    private static final int CARD = 0xFFFFFFFF;
    private static final int TEXT = 0xFF212121;
    private static final int TEXT_SOFT = 0xFF616161;
    private static final int ERROR = 0xFFB3261E;
    private static final int WARN_BG = 0xFFFFF4D6;
    private static final int WARN_TEXT = 0xFF5D4300;
    private static final int OK_BG = 0xFFE6F4EA;

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    /** Status bar colors the person can pick for their app. null means the default. */
    private static final String[] SWATCHES = {
            null, "#1E88E5", "#43A047", "#E53935", "#FB8C00", "#8E24AA", "#212121", "#FFFFFF"};

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final String fallbackSuffix = randomLetters(5);

    private Uri projectUri;
    private Uri iconUri;
    private File builtApk;
    private boolean packageEdited;
    private boolean settingPackage;
    private int selectedSwatch;

    private ScrollView scroll;
    private LinearLayout root;

    private Button chooseProjectBtn;
    private TextView projectLabel;
    private EditText nameField;
    private EditText versionField;
    private EditText packageField;
    private ImageView iconPreview;
    private Button chooseIconBtn;
    private TextView removeIconLink;
    private Switch fullscreenSwitch;
    private Switch keepOnSwitch;
    private Switch pullSwitch;
    private RadioGroup orientationGroup;
    private RadioButton rbAuto;
    private RadioButton rbPortrait;
    private RadioButton rbLandscape;
    private final TextView[] swatchViews = new TextView[SWATCHES.length];

    private Button buildBtn;
    private LinearLayout statusCard;
    private ProgressBar progressBar;
    private TextView logView;
    private TextView errorView;
    private LinearLayout warnCard;
    private LinearLayout warnList;
    private LinearLayout resultCard;
    private TextView resultDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, 0, 0, dp(32));
        scroll.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));
        setContentView(scroll);

        buildHeader();
        buildProjectCard();
        buildDetailsCard();
        buildIconCard();
        buildOptionsCard();
        buildActionArea();

        refreshSwatches();
        setPackageText(suggestPackage(""));
    }

    // ================================================================ screen parts

    private void buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(28), dp(20), dp(28));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PRIMARY);
        float r = dp(28);
        bg.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        header.setBackground(bg);

        header.addView(text("HTML to APK", 28, Color.WHITE, true));
        TextView sub = text("Turn your website into an Android app. "
                + "It all happens on this phone, no internet needed.", 14, 0xFFFFE0CC, false);
        sub.setPadding(0, dp(6), 0, 0);
        header.addView(sub);
        root.addView(header, new LinearLayout.LayoutParams(MATCH, WRAP));
    }

    private void buildProjectCard() {
        LinearLayout c = card(CARD, "1", "Your website");
        c.addView(text("Choose a .zip file with your website. It must contain a file called "
                + "index.html. A single .html file also works.", 13, TEXT_SOFT, false));

        chooseProjectBtn = button("Choose .zip or .html file", false);
        chooseProjectBtn.setOnClickListener(v -> pick("*/*", REQ_PROJECT));
        c.addView(chooseProjectBtn, lp(MATCH, WRAP, 0, 12, 0, 0));

        projectLabel = text("Nothing chosen yet", 14, TEXT_SOFT, false);
        c.addView(projectLabel, lp(MATCH, WRAP, 0, 10, 0, 0));
    }

    private void buildDetailsCard() {
        LinearLayout c = card(CARD, "2", "App details");

        c.addView(label("App name"));
        nameField = field("My App");
        c.addView(nameField, lp(MATCH, WRAP, 0, 4, 0, 0));

        c.addView(label("Version"));
        versionField = field("1.0");
        versionField.setText("1.0");
        c.addView(versionField, lp(MATCH, WRAP, 0, 4, 0, 0));

        c.addView(label("Package name (the app's unique ID)"));
        packageField = field("com.webapp.myapp");
        packageField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        c.addView(packageField, lp(MATCH, WRAP, 0, 4, 0, 0));
        c.addView(text("Filled in from the app name. Use the same package name again to update "
                + "an app you already installed.", 12, TEXT_SOFT, false), lp(MATCH, WRAP, 0, 6, 0, 0));

        nameField.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                nameField.setError(null);
                if (!packageEdited) {
                    setPackageText(suggestPackage(s.toString()));
                }
            }
        });
        versionField.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                versionField.setError(null);
            }
        });
        packageField.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                packageField.setError(null);
                if (!settingPackage) {
                    packageEdited = true;
                }
            }
        });
    }

    private void buildIconCard() {
        LinearLayout c = card(CARD, "3", "Icon (optional)");

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        iconPreview = new ImageView(this);
        iconPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable placeholder = new GradientDrawable();
        placeholder.setColor(0xFFEEEEEE);
        placeholder.setCornerRadius(dp(14));
        iconPreview.setBackground(placeholder);
        iconPreview.setClipToOutline(true);
        iconPreview.setContentDescription("Chosen icon");
        row.addView(iconPreview, new LinearLayout.LayoutParams(dp(64), dp(64)));

        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        chooseIconBtn = button("Choose picture", false);
        chooseIconBtn.setOnClickListener(v -> pick("image/*", REQ_ICON));
        side.addView(chooseIconBtn, new LinearLayout.LayoutParams(MATCH, WRAP));
        removeIconLink = text("Remove icon", 13, PRIMARY, true);
        removeIconLink.setPadding(dp(4), dp(8), dp(4), dp(4));
        removeIconLink.setVisibility(View.GONE);
        removeIconLink.setOnClickListener(v -> {
            iconUri = null;
            iconPreview.setImageDrawable(null);
            removeIconLink.setVisibility(View.GONE);
        });
        side.addView(removeIconLink, new LinearLayout.LayoutParams(WRAP, WRAP));
        LinearLayout.LayoutParams sideParams = new LinearLayout.LayoutParams(0, WRAP, 1f);
        sideParams.leftMargin = dp(14);
        row.addView(side, sideParams);
        c.addView(row, lp(MATCH, WRAP, 0, 4, 0, 0));

        c.addView(text("A square picture, at least 192 x 192 pixels, looks best. "
                + "Without one, a default icon is used.", 12, TEXT_SOFT, false), lp(MATCH, WRAP, 0, 8, 0, 0));
    }

    private void buildOptionsCard() {
        LinearLayout c = card(CARD, "4", "App settings");

        fullscreenSwitch = switchRow(c, "Full screen", "Hide the status bar and the navigation buttons");
        keepOnSwitch = switchRow(c, "Keep screen on", "The screen stays on while the app is open");
        pullSwitch = switchRow(c, "Pull down to refresh", "Drag down from the top of the page to reload it");

        c.addView(label("Screen rotation"));
        orientationGroup = new RadioGroup(this);
        orientationGroup.setOrientation(RadioGroup.HORIZONTAL);
        rbAuto = radio("Auto");
        rbPortrait = radio("Portrait");
        rbLandscape = radio("Landscape");
        orientationGroup.addView(rbAuto);
        orientationGroup.addView(rbPortrait);
        orientationGroup.addView(rbLandscape);
        orientationGroup.check(rbAuto.getId());
        c.addView(orientationGroup, lp(MATCH, WRAP, 0, 2, 0, 0));

        c.addView(label("Status bar color"));
        HorizontalScrollView scrollRow = new HorizontalScrollView(this);
        scrollRow.setHorizontalScrollBarEnabled(false);
        LinearLayout swatches = new LinearLayout(this);
        swatches.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < SWATCHES.length; i++) {
            final int index = i;
            TextView sw = new TextView(this);
            sw.setGravity(Gravity.CENTER);
            sw.setTextColor(TEXT_SOFT);
            sw.setTextSize(16);
            sw.setText(i == 0 ? "A" : "");
            sw.setContentDescription(i == 0 ? "Default status bar color" : "Status bar color " + SWATCHES[i]);
            sw.setOnClickListener(v -> {
                selectedSwatch = index;
                refreshSwatches();
            });
            swatchViews[i] = sw;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(40), dp(40));
            p.rightMargin = dp(10);
            swatches.addView(sw, p);
        }
        scrollRow.addView(swatches);
        c.addView(scrollRow, lp(MATCH, WRAP, 0, 6, 0, 0));
        c.addView(text("The first circle keeps the default color.", 12, TEXT_SOFT, false),
                lp(MATCH, WRAP, 0, 4, 0, 0));
    }

    private void buildActionArea() {
        buildBtn = button("Build APK", true);
        buildBtn.setTextSize(17);
        buildBtn.setMinHeight(dp(56));
        buildBtn.setMinimumHeight(dp(56));
        buildBtn.setOnClickListener(v -> startBuild());
        root.addView(buildBtn, lp(MATCH, WRAP, 16, 20, 16, 0));

        // progress and messages while building
        statusCard = card(CARD, null, null);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setIndeterminate(true);
        statusCard.addView(progressBar, new LinearLayout.LayoutParams(MATCH, WRAP));
        logView = text("", 13, TEXT_SOFT, false);
        logView.setTextIsSelectable(true);
        statusCard.addView(logView, lp(MATCH, WRAP, 0, 8, 0, 0));
        errorView = text("", 14, ERROR, true);
        errorView.setTextIsSelectable(true);
        errorView.setVisibility(View.GONE);
        statusCard.addView(errorView, lp(MATCH, WRAP, 0, 8, 0, 0));
        statusCard.setVisibility(View.GONE);

        // things to check (warnings)
        warnCard = card(WARN_BG, null, null);
        warnCard.addView(text("Things to check", 15, WARN_TEXT, true));
        warnList = new LinearLayout(this);
        warnList.setOrientation(LinearLayout.VERTICAL);
        warnCard.addView(warnList, lp(MATCH, WRAP, 0, 4, 0, 0));
        warnCard.setVisibility(View.GONE);

        // result
        resultCard = card(OK_BG, null, null);
        resultCard.addView(text("Your app is ready", 18, TEXT, true));
        resultDetail = text("", 13, TEXT_SOFT, false);
        resultCard.addView(resultDetail, lp(MATCH, WRAP, 0, 2, 0, 0));

        Button installBtn = button("Install", true);
        installBtn.setOnClickListener(v -> install());
        resultCard.addView(installBtn, lp(MATCH, WRAP, 0, 12, 0, 0));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button saveBtn = button("Save APK", false);
        saveBtn.setOnClickListener(v -> chooseSaveLocation());
        Button shareBtn = button("Share", false);
        shareBtn.setOnClickListener(v -> share());
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, WRAP, 1f);
        left.rightMargin = dp(8);
        row.addView(saveBtn, left);
        row.addView(shareBtn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        resultCard.addView(row, lp(MATCH, WRAP, 0, 8, 0, 0));

        resultCard.addView(text("If Android says \"App not installed\", another app with the same package "
                + "name may already be on this phone. Uninstall it, or change the package name above.",
                12, TEXT_SOFT, false), lp(MATCH, WRAP, 0, 10, 0, 0));
        resultCard.setVisibility(View.GONE);
    }

    // ================================================================ choosing files

    private void pick(String mime, int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        startActivityForResult(i, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_PROJECT) {
            projectUri = uri;
            String name = displayName(uri);
            long size = displaySize(uri);
            projectLabel.setText("Chosen: " + name + (size > 0 ? "  (" + formatSize(size) + ")" : ""));
            projectLabel.setTextColor(TEXT);
            if (nameField.getText().toString().trim().isEmpty()) {
                int dot = name.lastIndexOf('.');
                nameField.setText(dot > 0 ? name.substring(0, dot) : name);
            }
            warnCard.setVisibility(View.GONE);
            resultCard.setVisibility(View.GONE);
        } else if (requestCode == REQ_ICON) {
            iconUri = uri;
            loadPreview(uri);
            removeIconLink.setVisibility(View.VISIBLE);
        } else if (requestCode == REQ_SAVE) {
            saveTo(uri);
        }
    }

    /** Shows a small preview. The picture is shrunk while reading so big photos cannot crash the app. */
    private void loadPreview(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in != null) {
                    BitmapFactory.decodeStream(in, null, bounds);
                }
            }
            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= 256 && bounds.outHeight / (sample * 2) >= 256) {
                sample *= 2;
            }
            BitmapFactory.Options real = new BitmapFactory.Options();
            real.inSampleSize = sample;
            Bitmap bitmap = null;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in != null) {
                    bitmap = BitmapFactory.decodeStream(in, null, real);
                }
            }
            if (bitmap == null) {
                iconPreview.setImageDrawable(null);
                toast("That picture could not be read. Use a PNG or JPG.");
            } else {
                iconPreview.setImageBitmap(bitmap);
            }
        } catch (Throwable t) {
            iconPreview.setImageDrawable(null);
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (col >= 0 && c.getString(col) != null) {
                    return c.getString(col);
                }
            }
        } catch (Exception ignored) {
            // fall through
        }
        return "selected file";
    }

    private long displaySize(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(OpenableColumns.SIZE);
                if (col >= 0 && !c.isNull(col)) {
                    return c.getLong(col);
                }
            }
        } catch (Exception ignored) {
            // size is optional
        }
        return -1;
    }

    private static String formatSize(long bytes) {
        if (bytes >= 1024L * 1024) {
            return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        }
        return Math.max(1, bytes / 1024) + " KB";
    }

    // ================================================================ building

    /** Reads the screen. Shows a message next to the first problem and returns null if something is wrong. */
    private BuildOptions readOptions() {
        String name = nameField.getText().toString().trim();
        String version = versionField.getText().toString().trim();
        String pkg = packageField.getText().toString().trim();
        View firstProblem = null;

        if (projectUri == null) {
            projectLabel.setText("Choose your website file first");
            projectLabel.setTextColor(ERROR);
            firstProblem = chooseProjectBtn;
        }
        String e = BuildOptions.checkName(name);
        if (e != null) {
            nameField.setError(e);
            if (firstProblem == null) {
                firstProblem = nameField;
            }
        }
        e = BuildOptions.checkVersion(version);
        if (e != null) {
            versionField.setError(e);
            if (firstProblem == null) {
                firstProblem = versionField;
            }
        }
        e = BuildOptions.checkPackage(pkg);
        if (e != null) {
            packageField.setError(e);
            if (firstProblem == null) {
                firstProblem = packageField;
            }
        }
        if (firstProblem != null) {
            final int y = Math.max(0, topOf(firstProblem) - dp(90));
            scroll.post(() -> scroll.smoothScrollTo(0, y));
            return null;
        }

        BuildOptions o = new BuildOptions();
        o.appName = name;
        o.versionName = version;
        o.packageName = pkg;
        int checked = orientationGroup.getCheckedRadioButtonId();
        if (checked == rbPortrait.getId()) {
            o.orientation = BuildOptions.PORTRAIT;
        } else if (checked == rbLandscape.getId()) {
            o.orientation = BuildOptions.LANDSCAPE;
        } else {
            o.orientation = BuildOptions.AUTO;
        }
        o.fullscreen = fullscreenSwitch.isChecked();
        o.keepScreenOn = keepOnSwitch.isChecked();
        o.pullToRefresh = pullSwitch.isChecked();
        o.statusBarColor = SWATCHES[selectedSwatch];
        return o;
    }

    private void startBuild() {
        final BuildOptions options = readOptions();
        if (options == null) {
            return;
        }
        final Uri project = projectUri;
        final Uri icon = iconUri;

        setBusy(true);
        statusCard.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);
        logView.setText("");
        errorView.setVisibility(View.GONE);
        warnCard.setVisibility(View.GONE);
        resultCard.setVisibility(View.GONE);
        builtApk = null;
        scroll.post(() -> scroll.smoothScrollTo(0, statusCard.getTop()));

        executor.execute(() -> {
            try {
                final ApkBuilder.Result result = ApkBuilder.build(this, project, icon, options,
                        step -> ui.post(() -> appendLog(step)));
                ui.post(() -> showResult(result));
            } catch (Throwable t) {
                final String message = BuildException.friendly(t);
                ui.post(() -> showError(message));
            }
        });
    }

    private void showResult(ApkBuilder.Result result) {
        builtApk = result.apk;
        progressBar.setVisibility(View.GONE);
        setBusy(false);

        warnList.removeAllViews();
        List<String> warnings = result.warnings;
        for (String w : warnings) {
            TextView t = text("• " + w, 13, WARN_TEXT, false);
            t.setTextIsSelectable(true);
            warnList.addView(t, lp(MATCH, WRAP, 0, 4, 0, 0));
        }
        warnCard.setVisibility(warnings.isEmpty() ? View.GONE : View.VISIBLE);

        resultDetail.setText(result.apk.getName() + "  -  " + formatSize(result.apk.length()));
        resultCard.setVisibility(View.VISIBLE);
        scroll.post(() -> scroll.smoothScrollTo(0, statusCard.getTop()));
    }

    private void showError(String message) {
        progressBar.setVisibility(View.GONE);
        errorView.setText("Could not build the app.\n" + message);
        errorView.setVisibility(View.VISIBLE);
        setBusy(false);
    }

    private void setBusy(boolean busy) {
        buildBtn.setEnabled(!busy);
        buildBtn.setAlpha(busy ? 0.5f : 1f);
        buildBtn.setText(busy ? "Building..." : "Build APK");
        chooseProjectBtn.setEnabled(!busy);
        chooseIconBtn.setEnabled(!busy);
    }

    private void appendLog(String line) {
        CharSequence old = logView.getText();
        logView.setText(old.length() == 0 ? line : old + "\n" + line);
    }

    // ================================================================ install / save / share

    private Uri apkUri() {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", builtApk);
    }

    private void install() {
        if (builtApk == null || !builtApk.exists()) {
            toast("Build the app first");
            return;
        }
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            toast("Allow \"Install unknown apps\" for HTML to APK, then come back and press Install again");
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(apkUri(), "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Could not open the installer: " + e.getMessage());
        }
    }

    private void share() {
        if (builtApk == null || !builtApk.exists()) {
            toast("Build the app first");
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_STREAM, apkUri());
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "Share APK"));
        } catch (Exception e) {
            toast("Could not share: " + e.getMessage());
        }
    }

    private void chooseSaveLocation() {
        if (builtApk == null) {
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_TITLE, builtApk.getName());
        startActivityForResult(i, REQ_SAVE);
    }

    private void saveTo(final Uri target) {
        final File source = builtApk;
        if (source == null) {
            return;
        }
        executor.execute(() -> {
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(target)) {
                if (out == null) {
                    throw new java.io.IOException("Cannot write to that location");
                }
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
                ui.post(() -> toast("APK saved"));
            } catch (Exception e) {
                final String message = BuildException.friendly(e);
                ui.post(() -> toast("Could not save: " + message));
            }
        });
    }

    // ================================================================ package name

    private void setPackageText(String value) {
        settingPackage = true;
        packageField.setText(value);
        settingPackage = false;
    }

    /** com.webapp.<letters and digits of the name>. Names without letters (for example Bengali) get a random ending. */
    private String suggestPackage(String appName) {
        StringBuilder sb = new StringBuilder();
        String lower = appName.toLowerCase(Locale.ROOT);
        for (int i = 0; i < lower.length(); i++) {
            char ch = lower.charAt(i);
            if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) {
                sb.append(ch);
            }
        }
        String slug = sb.toString();
        if (slug.isEmpty()) {
            slug = "app" + fallbackSuffix;
        } else if (Character.isDigit(slug.charAt(0))) {
            slug = "app" + slug;
        }
        if (slug.length() > 30) {
            slug = slug.substring(0, 30);
        }
        return "com.webapp." + slug;
    }

    // ================================================================ view helpers

    private void refreshSwatches() {
        for (int i = 0; i < SWATCHES.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(i == 0 ? 0xFFEEEEEE : Color.parseColor(SWATCHES[i]));
            boolean selected = i == selectedSwatch;
            g.setStroke(dp(selected ? 3 : 1), selected ? TEXT : 0xFFBDBDBD);
            swatchViews[i].setBackground(g);
        }
    }

    /** A white rounded box added to the screen. {@code title} may be null for a box without heading. */
    private LinearLayout card(int color, String number, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(16));
        c.setBackground(bg);
        c.setElevation(dp(2));
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.addView(c, lp(MATCH, WRAP, 16, 14, 16, 0));

        if (title != null) {
            LinearLayout head = new LinearLayout(this);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView badge = text(number, 14, Color.WHITE, true);
            badge.setGravity(Gravity.CENTER);
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(PRIMARY);
            badge.setBackground(circle);
            head.addView(badge, new LinearLayout.LayoutParams(dp(28), dp(28)));
            TextView t = text(title, 18, TEXT, true);
            t.setPadding(dp(10), 0, 0, 0);
            head.addView(t);
            c.addView(head, lp(MATCH, WRAP, 0, 0, 0, 10));
        }
        return c;
    }

    private TextView text(String s, int sizeSp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, TEXT_SOFT, true);
        t.setPadding(0, dp(14), 0, 0);
        return t;
    }

    private Button button(String label, boolean filled) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(filled ? Color.WHITE : PRIMARY);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        if (filled) {
            bg.setColor(PRIMARY);
        } else {
            bg.setColor(Color.WHITE);
            bg.setStroke(dp(2), PRIMARY);
        }
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33000000), bg, null));
        b.setStateListAnimator(null);
        b.setMinHeight(dp(48));
        b.setMinimumHeight(dp(48));
        return b;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(TEXT);
        e.setHintTextColor(0xFF9E9E9E);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), 0xFFBDBDBD);
        e.setBackground(bg);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        return e;
    }

    private Switch switchRow(LinearLayout parent, String title, String detail) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(title, 16, TEXT, false));
        texts.addView(text(detail, 12, TEXT_SOFT, false));
        row.addView(texts, new LinearLayout.LayoutParams(0, WRAP, 1f));
        final Switch sw = new Switch(this);
        row.addView(sw, new LinearLayout.LayoutParams(WRAP, WRAP));
        row.setOnClickListener(v -> sw.toggle());
        parent.addView(row, lp(MATCH, WRAP, 0, 14, 0, 0));
        return sw;
    }

    private RadioButton radio(String label) {
        RadioButton r = new RadioButton(this);
        r.setId(View.generateViewId());
        r.setText(label);
        r.setTextSize(14);
        r.setTextColor(TEXT);
        return r;
    }

    private int topOf(View v) {
        int y = 0;
        View cur = v;
        while (cur != null && cur != root) {
            y += cur.getTop();
            ViewParent p = cur.getParent();
            cur = p instanceof View ? (View) p : null;
        }
        return y;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static String randomLetters(int n) {
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append((char) ('a' + r.nextInt(26)));
        }
        return sb.toString();
    }

    /** A TextWatcher where only afterTextChanged needs to be written. */
    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
