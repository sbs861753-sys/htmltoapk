package com.htmltoapk.builder;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.zip.ZipException;

/** An error whose message is already written for the person using the app. */
final class BuildException extends IOException {

    BuildException(String message) {
        super(message);
    }

    /** Turns any error into a short message a non-programmer can act on. */
    static String friendly(Throwable t) {
        if (t instanceof BuildException) {
            return t.getMessage();
        }
        if (t instanceof OutOfMemoryError) {
            return "The phone ran out of memory. Close other apps, or use a smaller website, and try again.";
        }
        String m = t.getMessage() == null ? "" : t.getMessage();
        String lower = m.toLowerCase();
        if (lower.contains("enospc") || lower.contains("no space left")) {
            return "The phone storage is full. Free some space and try again.";
        }
        if (t instanceof SecurityException) {
            return "The app was not allowed to read that file. Choose the file again.";
        }
        if (t instanceof ZipException) {
            return "The zip file looks damaged. Create the zip again and retry.";
        }
        if (t instanceof FileNotFoundException) {
            return "A file could not be opened. Choose your files again.";
        }
        if (m.isEmpty()) {
            return "Something went wrong (" + t.getClass().getSimpleName() + ").";
        }
        return "Something went wrong: " + m;
    }
}
