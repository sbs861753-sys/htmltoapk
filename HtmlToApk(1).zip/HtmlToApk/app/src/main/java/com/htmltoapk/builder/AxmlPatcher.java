package com.htmltoapk.builder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Changes text inside a compiled (binary) AndroidManifest.xml.
 *
 * A compiled manifest keeps every piece of text (package name, app label...)
 * in one "string pool" and everything else points at it by number. So we can
 * rewrite the pool with new text and leave the rest of the file untouched.
 */
final class AxmlPatcher {

    private static final int CHUNK_XML = 0x0003;
    private static final int CHUNK_STRING_POOL = 0x0001;
    private static final int FLAG_UTF8 = 0x100;

    private AxmlPatcher() {
    }

    /**
     * Replaces every string that is exactly equal to a key of {@code replacements}.
     * Fails if one of the keys is not found, which means the template changed.
     */
    static byte[] replaceStrings(byte[] data, Map<String, String> replacements) throws IOException {
        ByteBuffer in = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if (data.length < 8 || (in.getShort(0) & 0xFFFF) != CHUNK_XML) {
            throw new IOException("AndroidManifest.xml is not in binary format");
        }
        int fileHeaderSize = in.getShort(2) & 0xFFFF;
        int poolStart = fileHeaderSize;
        if ((in.getShort(poolStart) & 0xFFFF) != CHUNK_STRING_POOL) {
            throw new IOException("String pool not found in AndroidManifest.xml");
        }

        int poolHeaderSize = in.getShort(poolStart + 2) & 0xFFFF;
        int poolSize = in.getInt(poolStart + 4);
        int stringCount = in.getInt(poolStart + 8);
        int styleCount = in.getInt(poolStart + 12);
        int flags = in.getInt(poolStart + 16);
        int stringsStart = in.getInt(poolStart + 20);
        int stylesStart = in.getInt(poolStart + 24);
        boolean utf8 = (flags & FLAG_UTF8) != 0;

        int offsetsAt = poolStart + poolHeaderSize;
        int stringDataAt = poolStart + stringsStart;

        Set<String> found = new HashSet<>();
        byte[][] raw = new byte[stringCount][];
        for (int i = 0; i < stringCount; i++) {
            int start = stringDataAt + in.getInt(offsetsAt + 4 * i);
            String text = readString(data, start, utf8);
            int length = rawLength(data, start, utf8);
            String replacement = replacements.get(text);
            if (replacement != null) {
                found.add(text);
                raw[i] = encode(replacement, utf8);
            } else {
                raw[i] = Arrays.copyOfRange(data, start, start + length);
            }
        }
        for (String key : replacements.keySet()) {
            if (!found.contains(key)) {
                throw new IOException("Template manifest does not contain \"" + key + "\"");
            }
        }

        // Rebuild the string data block.
        ByteArrayOutputStream strings = new ByteArrayOutputStream();
        int[] newOffsets = new int[stringCount];
        for (int i = 0; i < stringCount; i++) {
            newOffsets[i] = strings.size();
            strings.write(raw[i]);
        }
        while (strings.size() % 4 != 0) {
            strings.write(0);
        }

        byte[] styleOffsets = Arrays.copyOfRange(data,
                offsetsAt + 4 * stringCount, offsetsAt + 4 * (stringCount + styleCount));
        byte[] styleData = styleCount > 0
                ? Arrays.copyOfRange(data, poolStart + stylesStart, poolStart + poolSize)
                : new byte[0];

        int newStringsStart = poolHeaderSize + 4 * (stringCount + styleCount);
        int newStylesStart = styleCount > 0 ? newStringsStart + strings.size() : 0;
        int newPoolSize = newStringsStart + strings.size() + styleData.length;

        ByteBuffer pool = ByteBuffer.allocate(newPoolSize).order(ByteOrder.LITTLE_ENDIAN);
        pool.put(data, poolStart, poolHeaderSize); // copy header, then fix the changed fields
        pool.putInt(4, newPoolSize);
        pool.putInt(20, newStringsStart);
        pool.putInt(24, newStylesStart);
        pool.position(poolHeaderSize);
        for (int offset : newOffsets) {
            pool.putInt(offset);
        }
        pool.put(styleOffsets);
        pool.put(strings.toByteArray());
        pool.put(styleData);

        int restStart = poolStart + poolSize;
        int total = fileHeaderSize + newPoolSize + (data.length - restStart);
        ByteBuffer out = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        out.put(data, 0, fileHeaderSize);
        out.putInt(4, total);
        out.position(fileHeaderSize);
        out.put(pool.array());
        out.put(data, restStart, data.length - restStart);
        return out.array();
    }

    // ---- reading ----

    private static String readString(byte[] d, int start, boolean utf8) throws IOException {
        int p = start;
        if (utf8) {
            int[] r = readLength8(d, p);
            p = r[1];
            r = readLength8(d, p); // second length = number of bytes
            return new String(d, r[1], r[0], "UTF-8");
        }
        int[] r = readLength16(d, p);
        return new String(d, r[1], r[0] * 2, "UTF-16LE");
    }

    private static int rawLength(byte[] d, int start, boolean utf8) {
        int p = start;
        if (utf8) {
            int[] r = readLength8(d, p);
            p = r[1];
            r = readLength8(d, p);
            return (r[1] - start) + r[0] + 1;
        }
        int[] r = readLength16(d, p);
        return (r[1] - start) + r[0] * 2 + 2;
    }

    /** Returns {length, positionAfterLength}. */
    private static int[] readLength8(byte[] d, int p) {
        int len = d[p] & 0xFF;
        if ((len & 0x80) != 0) {
            len = ((len & 0x7F) << 8) | (d[p + 1] & 0xFF);
            return new int[]{len, p + 2};
        }
        return new int[]{len, p + 1};
    }

    private static int[] readLength16(byte[] d, int p) {
        int len = (d[p] & 0xFF) | ((d[p + 1] & 0xFF) << 8);
        if ((len & 0x8000) != 0) {
            int low = (d[p + 2] & 0xFF) | ((d[p + 3] & 0xFF) << 8);
            len = ((len & 0x7FFF) << 16) | low;
            return new int[]{len, p + 4};
        }
        return new int[]{len, p + 2};
    }

    // ---- writing ----

    private static byte[] encode(String s, boolean utf8) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        if (utf8) {
            byte[] b = s.getBytes("UTF-8");
            if (s.length() > 0x7FFF || b.length > 0x7FFF) {
                throw new IOException("Text is too long");
            }
            writeLength8(o, s.length());
            writeLength8(o, b.length);
            o.write(b);
            o.write(0);
        } else {
            byte[] b = s.getBytes("UTF-16LE");
            int n = s.length();
            if (n > 0x7FFF) {
                write16(o, (n >> 16) | 0x8000);
                write16(o, n & 0xFFFF);
            } else {
                write16(o, n);
            }
            o.write(b);
            write16(o, 0);
        }
        return o.toByteArray();
    }

    private static void writeLength8(ByteArrayOutputStream o, int n) {
        if (n > 0x7F) {
            o.write((n >> 8) | 0x80);
            o.write(n & 0xFF);
        } else {
            o.write(n);
        }
    }

    private static void write16(ByteArrayOutputStream o, int v) {
        o.write(v & 0xFF);
        o.write((v >> 8) & 0xFF);
    }
}
