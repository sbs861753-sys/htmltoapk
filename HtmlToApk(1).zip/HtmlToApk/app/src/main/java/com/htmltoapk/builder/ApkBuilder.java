package com.htmltoapk.builder;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Turns a zip (or single .html file) into an installable APK, completely offline.
 *
 * 1. Checks the website (ProjectScanner).
 * 2. Takes the blank template APK that ships inside this app (assets/template.apk).
 * 3. Rewrites its manifest with the new app name, package name and version.
 * 4. Optionally swaps the launcher icon.
 * 5. Puts the website into assets/www and the chosen settings into assets/config.json.
 * 6. Signs the result with a key stored on this device and checks the signature.
 */
final class ApkBuilder {

    // These texts exist in the template's manifest and are replaced.
    static final String TEMPLATE_LABEL = "WebAppTemplateLabel";
    static final String TEMPLATE_VERSION = "TemplateVersionName";

    interface Progress {
        void step(String message);
    }

    static final class Result {
        final File apk;
        final List<String> warnings;
        final int fileCount;

        Result(File apk, List<String> warnings, int fileCount) {
            this.apk = apk;
            this.warnings = warnings;
            this.fileCount = fileCount;
        }
    }

    private ApkBuilder() {
    }

    static Result build(Context ctx, Uri project, Uri icon, BuildOptions opts, Progress progress)
            throws Exception {
        opts.validate();

        File work = new File(ctx.getCacheDir(), "work");
        deleteRecursive(work);
        if (!work.mkdirs()) {
            throw new BuildException("Cannot create a work folder on this phone.");
        }
        try {
            return doBuild(ctx, project, icon, opts, progress, work);
        } finally {
            deleteRecursive(work); // always clean up, even after an error
        }
    }

    private static Result doBuild(Context ctx, Uri project, Uri icon, BuildOptions opts,
                                  Progress progress, File work) throws Exception {
        File outDir = new File(ctx.getCacheDir(), "out");
        if (!outDir.exists() && !outDir.mkdirs()) {
            throw new BuildException("Cannot create the output folder on this phone.");
        }

        // ---- 1. read and check the website ----
        progress.step("Reading your files...");
        File input = new File(work, "input.bin");
        try (InputStream in = ctx.getContentResolver().openInputStream(project)) {
            if (in == null) {
                throw new BuildException("Cannot open the file you chose. Choose it again.");
            }
            copyToFile(in, input);
        }
        if (work.getUsableSpace() < input.length() * 2 + 20L * 1024 * 1024) {
            throw new BuildException("The phone storage is almost full. Free some space and try again.");
        }

        ProjectScanner.Kind kind = ProjectScanner.detectKind(input);
        ProjectScanner.Result scan = kind == ProjectScanner.Kind.ZIP
                ? ProjectScanner.scanZip(input) : ProjectScanner.scanHtml(input);
        progress.step("Found " + scan.files.size() + " files.");

        List<String> warnings = new ArrayList<>(scan.warnings);

        // ---- 2. icon ----
        Bitmap iconBitmap = null;
        if (icon != null) {
            iconBitmap = decodeIcon(ctx, icon);
            if (iconBitmap.getWidth() < 192) {
                warnings.add("The icon picture is small (" + iconBitmap.getWidth()
                        + " pixels). It may look blurry. Use at least 192 x 192.");
            }
        }

        // ---- 3. template ----
        File template = new File(work, "template.apk");
        try (InputStream in = ctx.getAssets().open("template.apk")) {
            copyToFile(in, template);
        } catch (FileNotFoundException e) {
            throw new BuildException("template.apk is missing inside this app. "
                    + "Build the project with Gradle so the 'template' module is built first.");
        }

        // ---- 4. assemble ----
        progress.step("Building the app...");
        File unsigned = new File(work, "unsigned.apk");
        boolean iconReplaced = false;
        try (ZipFile templateZip = new ZipFile(template);
             AlignedZipWriter writer = new AlignedZipWriter(new FileOutputStream(unsigned))) {

            Enumeration<? extends ZipEntry> entries = templateZip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement();
                String name = e.getName();
                if (e.isDirectory() || name.startsWith("META-INF/")
                        || name.startsWith("assets/www/") || name.equals("assets/config.json")) {
                    continue; // old signature and the template's placeholder files are dropped
                }
                byte[] data = readAll(templateZip.getInputStream(e));

                if (name.equals("AndroidManifest.xml")) {
                    Map<String, String> changes = new HashMap<>();
                    changes.put(BuildOptions.TEMPLATE_PACKAGE, opts.packageName);
                    changes.put(TEMPLATE_LABEL, opts.appName.trim());
                    changes.put(TEMPLATE_VERSION, opts.versionName);
                    writer.addDeflated(name, AxmlPatcher.replaceStrings(data, changes));
                } else if (name.equals("resources.arsc")) {
                    writer.addStoredAligned(name, data, 4); // required by Android 11+
                } else if (iconBitmap != null && isLauncherIcon(name)) {
                    writer.addDeflated(name, scaledPng(iconBitmap, data));
                    iconReplaced = true;
                } else {
                    writer.addDeflated(name, data);
                }
            }

            writer.addDeflated("assets/config.json", opts.toConfigJson().getBytes("UTF-8"));

            progress.step("Adding your web files...");
            if (kind == ProjectScanner.Kind.ZIP) {
                try (ZipFile site = new ZipFile(input)) {
                    for (ProjectScanner.Entry entry : scan.files) {
                        ZipEntry ze = site.getEntry(entry.zipName);
                        if (ze == null) {
                            continue;
                        }
                        try (InputStream in = site.getInputStream(ze)) {
                            writer.addDeflated("assets/www/" + entry.path, in);
                        }
                    }
                }
            } else {
                try (InputStream in = new FileInputStream(input)) {
                    writer.addDeflated("assets/www/index.html", in);
                }
            }
        }
        if (iconBitmap != null && !iconReplaced) {
            warnings.add("The icon could not be replaced, so the default icon is used.");
        }

        // ---- 5. sign and check ----
        progress.step("Signing the app...");
        SigningKey key = SigningKey.loadOrCreate(new File(ctx.getFilesDir(), "signing"));
        File signed = new File(outDir, opts.packageName + ".apk");
        if (signed.exists() && !signed.delete()) {
            throw new BuildException("Cannot replace the previous build. Try again.");
        }
        ApkSigner.SignerConfig signer = new ApkSigner.SignerConfig.Builder(
                "webapp", key.privateKey, Collections.singletonList(key.certificate)).build();
        new ApkSigner.Builder(Collections.singletonList(signer))
                .setInputApk(unsigned)
                .setOutputApk(signed)
                .setMinSdkVersion(24)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .build()
                .sign();

        ApkVerifier.Result check = new ApkVerifier.Builder(signed)
                .setMinCheckedPlatformVersion(24)
                .build()
                .verify();
        if (!check.isVerified()) {
            signed.delete();
            throw new BuildException("The finished app failed its safety check (" + check.getErrors()
                    + "). It was not kept.");
        }

        progress.step("Done. " + scan.files.size() + " files, " + (signed.length() / 1024) + " KB.");
        return new Result(signed, warnings, scan.files.size());
    }

    // ---- icon ----

    /**
     * Release builds often rename resource files to short names (res/Ab.png), so the name
     * "ic_launcher" cannot be relied on. The template has no libraries, which means the only
     * PNG pictures inside it are its launcher icons, so every PNG under res/ is replaced.
     */
    private static boolean isLauncherIcon(String entryName) {
        return entryName.startsWith("res/") && entryName.toLowerCase().endsWith(".png");
    }

    /** Reads the picture, shrinking huge photos while reading so the phone does not run out of memory. */
    private static Bitmap decodeIcon(Context ctx, Uri icon) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = ctx.getContentResolver().openInputStream(icon)) {
            if (in == null) {
                throw new BuildException("Cannot open the icon picture. Choose it again.");
            }
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new BuildException("The icon could not be read. Use a PNG or JPG picture.");
        }
        int sample = 1;
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) {
            sample *= 2;
        }
        BitmapFactory.Options real = new BitmapFactory.Options();
        real.inSampleSize = sample;
        Bitmap bitmap;
        try (InputStream in = ctx.getContentResolver().openInputStream(icon)) {
            bitmap = in == null ? null : BitmapFactory.decodeStream(in, null, real);
        }
        if (bitmap == null) {
            throw new BuildException("The icon could not be read. Use a PNG or JPG picture.");
        }
        int side = Math.min(bitmap.getWidth(), bitmap.getHeight());
        int x = (bitmap.getWidth() - side) / 2;
        int y = (bitmap.getHeight() - side) / 2;
        return Bitmap.createBitmap(bitmap, x, y, side, side);
    }

    /** Scales the chosen picture to the same size as the template icon it replaces. */
    private static byte[] scaledPng(Bitmap square, byte[] oldIcon) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(oldIcon, 0, oldIcon.length, bounds);
        int size = bounds.outWidth > 0 ? bounds.outWidth : 192;
        Bitmap scaled = Bitmap.createScaledBitmap(square, size, size, true);
        ByteArrayOutputStream png = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.PNG, 100, png);
        return png.toByteArray();
    }

    // ---- small helpers ----

    private static byte[] readAll(InputStream in) throws IOException {
        try (InputStream src = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[1 << 14];
            int n;
            while ((n = src.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    private static void copyToFile(InputStream in, File target) throws IOException {
        try (OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
        }
    }

    static void deleteRecursive(File f) {
        if (f == null || !f.exists()) {
            return;
        }
        File[] children = f.listFiles();
        if (children != null) {
            for (File c : children) {
                deleteRecursive(c);
            }
        }
        // ignore the result, leftover cache files are harmless
        f.delete();
    }
}
