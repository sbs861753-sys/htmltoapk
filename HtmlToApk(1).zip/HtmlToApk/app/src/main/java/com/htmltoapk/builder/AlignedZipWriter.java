package com.htmltoapk.builder;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Writes a ZIP (APK) file.
 *
 * Android 11+ refuses to install apps whose resources.arsc is compressed or
 * not aligned to 4 bytes. This writer can store a file uncompressed and pad
 * its header so the file data starts on a 4-byte boundary (what the
 * "zipalign" tool normally does).
 */
final class AlignedZipWriter implements Closeable {

    /** Fixed timestamp (2020-01-01) so output does not depend on the clock. */
    private static final long FIXED_TIME = 1577836800000L;

    private static final class CountingStream extends FilterOutputStream {
        long count;

        CountingStream(OutputStream out) {
            super(out);
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            count++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }
    }

    private final CountingStream counter;
    private final ZipOutputStream zip;

    AlignedZipWriter(OutputStream out) {
        counter = new CountingStream(new BufferedOutputStream(out, 1 << 16));
        zip = new ZipOutputStream(counter);
    }

    void addDeflated(String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.DEFLATED);
        e.setTime(FIXED_TIME);
        zip.putNextEntry(e);
        zip.write(data);
        zip.closeEntry();
    }

    void addDeflated(String name, InputStream in) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.DEFLATED);
        e.setTime(FIXED_TIME);
        zip.putNextEntry(e);
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) != -1) {
            zip.write(buf, 0, n);
        }
        zip.closeEntry();
    }

    /** Stores the file uncompressed, with its data starting on a multiple of {@code alignment} bytes. */
    void addStoredAligned(String name, byte[] data, int alignment) throws IOException {
        CRC32 crc = new CRC32();
        crc.update(data);

        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.STORED);
        e.setSize(data.length);
        e.setCompressedSize(data.length);
        e.setCrc(crc.getValue());
        e.setTime(FIXED_TIME);

        // Local file header = 30 fixed bytes + file name + extra field, then the data.
        int nameLength = name.getBytes("UTF-8").length;
        long dataStart = counter.count + 30 + nameLength;
        int pad = (int) ((alignment - (dataStart % alignment)) % alignment);
        if (pad > 0) {
            int extraLength = pad;
            while (extraLength < 4) { // an extra field needs at least a 4 byte header
                extraLength += alignment;
            }
            byte[] extra = new byte[extraLength];
            extra[0] = (byte) 0x35; // id 0xD935 = the "zipalign" padding field
            extra[1] = (byte) 0xD9;
            extra[2] = (byte) ((extraLength - 4) & 0xFF);
            extra[3] = (byte) (((extraLength - 4) >> 8) & 0xFF);
            e.setExtra(extra);
        }

        zip.putNextEntry(e);
        zip.write(data);
        zip.closeEntry();
    }

    @Override
    public void close() throws IOException {
        zip.close();
    }
}
