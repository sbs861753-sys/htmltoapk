package com.htmltoapk.builder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

/**
 * Looks at the website the person chose before anything is built:
 * finds the main page, drops junk files, enforces limits and
 * warns about problems such as missing images or files that need the internet.
 * Uses only plain Java so it can be tested on a computer.
 */
final class ProjectScanner {

    static final int MAX_FILES = 20000;
    static final long MAX_TOTAL_BYTES = 300L * 1024 * 1024;
    private static final long WARN_TOTAL_BYTES = 100L * 1024 * 1024;
    private static final long MAX_TEXT_FILE_BYTES = 1024 * 1024;
    private static final int MAX_TEXT_FILES = 300;
    private static final int MAX_LISTED = 6;

    enum Kind { ZIP, HTML }

    static final class Entry {
        /** Name exactly as stored in the zip. */
        final String zipName;
        /** Path inside the app's www folder. */
        final String path;

        Entry(String zipName, String path) {
            this.zipName = zipName;
            this.path = path;
        }
    }

    static final class Result {
        final List<Entry> files = new ArrayList<>();
        final List<String> warnings = new ArrayList<>();
        long totalBytes;
    }

    private ProjectScanner() {
    }

    // ------------------------------------------------------------------ kind

    /** Decides if the chosen file is a zip or a single web page, and rejects everything else. */
    static Kind detectKind(File f) throws IOException {
        byte[] head = new byte[2048];
        int n;
        try (InputStream in = new FileInputStream(f)) {
            n = readFully(in, head);
        }
        if (n == 0) {
            throw new BuildException("The file you chose is empty.");
        }
        if (n >= 2 && head[0] == 'P' && head[1] == 'K') {
            return Kind.ZIP;
        }
        if (n >= 4 && head[0] == 'R' && head[1] == 'a' && head[2] == 'r' && head[3] == '!') {
            throw new BuildException("RAR files are not supported. Please make a .zip file instead.");
        }
        if (n >= 4 && (head[0] & 0xFF) == 0x37 && head[1] == 0x7A
                && (head[2] & 0xFF) == 0xBC && (head[3] & 0xFF) == 0xAF) {
            throw new BuildException("7z files are not supported. Please make a .zip file instead.");
        }
        String text = new String(head, 0, n, "UTF-8").toLowerCase(Locale.ROOT);
        if (text.contains("<html") || text.contains("<!doctype html") || text.contains("<head")
                || text.contains("<body") || text.contains("<div") || text.contains("<script")
                || text.contains("<h1") || text.contains("<p>")) {
            return Kind.HTML;
        }
        throw new BuildException("Please choose a .zip file with your website, or a single .html file.");
    }

    // ------------------------------------------------------------ single html

    static Result scanHtml(File f) throws IOException {
        if (f.length() > MAX_TOTAL_BYTES) {
            throw new BuildException("This file is too big (limit 300 MB).");
        }
        Result r = new Result();
        r.files.add(new Entry(f.getName(), "index.html"));
        r.totalBytes = f.length();

        Map<String, String> texts = new LinkedHashMap<>();
        if (f.length() <= MAX_TEXT_FILE_BYTES) {
            try (InputStream in = new FileInputStream(f)) {
                texts.put("index.html", decode(readLimited(in, MAX_TEXT_FILE_BYTES)));
            }
        }
        Set<String> paths = new HashSet<>();
        paths.add("index.html");
        checkReferences(texts, paths, r, true);
        checkViewport(texts.get("index.html"), r);
        return r;
    }

    // -------------------------------------------------------------------- zip

    static Result scanZip(File file) throws IOException {
        ZipFile zip;
        try {
            zip = new ZipFile(file);
        } catch (ZipException e) {
            throw new BuildException("This zip file is damaged, or it is not a normal .zip file.");
        } catch (IllegalArgumentException e) {
            throw badNames();
        }
        try {
            return scanZipFile(zip);
        } catch (IllegalArgumentException e) {
            throw badNames();
        } finally {
            zip.close();
        }
    }

    private static BuildException badNames() {
        return new BuildException("Some file names inside the zip use characters that cannot be read. "
                + "Rename those files with simple names and create the zip again.");
    }

    private static Result scanZipFile(ZipFile zip) throws IOException {
        List<ZipEntry> entries = new ArrayList<>();
        List<String> names = new ArrayList<>();
        long total = 0;

        Enumeration<? extends ZipEntry> en = zip.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            String name = e.getName().replace('\\', '/');
            if (e.isDirectory() || name.isEmpty() || !isSafeName(name) || isJunk(name)) {
                continue;
            }
            entries.add(e);
            names.add(name);
            if (entries.size() > MAX_FILES) {
                throw new BuildException("The zip has too many files (limit " + MAX_FILES + ").");
            }
            if (e.getSize() > 0) {
                total += e.getSize();
            }
        }
        if (names.isEmpty()) {
            throw new BuildException("The zip file is empty.");
        }
        if (total > MAX_TOTAL_BYTES) {
            throw new BuildException("Your website is " + (total / (1024 * 1024))
                    + " MB. The limit is 300 MB. Remove big videos or unused files.");
        }

        Result r = new Result();
        r.totalBytes = total;

        // ---- find the main page: the shallowest index.html (any letter case) ----
        int bestDepth = Integer.MAX_VALUE;
        List<String> mains = new ArrayList<>();
        for (String n : names) {
            if (baseName(n).equalsIgnoreCase("index.html")) {
                int d = depth(n);
                if (d < bestDepth) {
                    bestDepth = d;
                    mains.clear();
                    mains.add(n);
                } else if (d == bestDepth) {
                    mains.add(n);
                }
            }
        }

        String main = null;
        if (mains.size() > 1) {
            throw new BuildException("The zip has " + mains.size() + " index.html files in different folders ("
                    + mains.get(0) + ", " + mains.get(1) + "...). Keep only one.");
        } else if (mains.size() == 1) {
            main = mains.get(0);
        } else {
            // No index.html: accept a single .html page and use it as the main page.
            int best = Integer.MAX_VALUE;
            List<String> pages = new ArrayList<>();
            for (String n : names) {
                String lower = n.toLowerCase(Locale.ROOT);
                if (lower.endsWith(".html") || lower.endsWith(".htm")) {
                    int d = depth(n);
                    if (d < best) {
                        best = d;
                        pages.clear();
                        pages.add(n);
                    } else if (d == best) {
                        pages.add(n);
                    }
                }
            }
            if (pages.isEmpty()) {
                throw new BuildException("No index.html found in the zip. Your main page must be called index.html.");
            }
            if (pages.size() > 1) {
                throw new BuildException("The zip has several .html files but no index.html. "
                        + "Rename your main page to index.html.");
            }
            main = pages.get(0);
        }

        String mainBase = baseName(main);
        String prefix = main.substring(0, main.length() - mainBase.length());
        boolean renameMain = !mainBase.equals("index.html");
        if (renameMain) {
            r.warnings.add("\"" + mainBase + "\" is used as the main page (renamed to index.html).");
        }

        // ---- choose files to include ----
        Set<String> used = new HashSet<>();
        int outside = 0;
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            if (!name.startsWith(prefix)) {
                outside++;
                continue;
            }
            String relative = name.equals(main) ? "index.html" : name.substring(prefix.length());
            if (relative.isEmpty() || !used.add(relative)) {
                continue;
            }
            r.files.add(new Entry(entries.get(i).getName(), relative));
        }
        if (outside > 0) {
            r.warnings.add(outside + " file(s) outside the folder \"" + prefix + "\" were not included.");
        }
        if (total > WARN_TOTAL_BYTES) {
            r.warnings.add("Your website is large (" + (total / (1024 * 1024))
                    + " MB). The app will take longer to build and install.");
        }

        // ---- read pages and style sheets to look for problems ----
        Map<String, String> texts = new LinkedHashMap<>();
        for (Entry e : r.files) {
            String lower = e.path.toLowerCase(Locale.ROOT);
            if (!(lower.endsWith(".html") || lower.endsWith(".htm") || lower.endsWith(".css"))) {
                continue;
            }
            if (texts.size() >= MAX_TEXT_FILES) {
                break;
            }
            ZipEntry ze = zip.getEntry(e.zipName);
            if (ze == null || ze.getSize() > MAX_TEXT_FILE_BYTES) {
                continue;
            }
            try (InputStream in = zip.getInputStream(ze)) {
                byte[] data = readLimited(in, MAX_TEXT_FILE_BYTES);
                if (data != null) {
                    texts.put(e.path, decode(data));
                }
            }
        }
        Set<String> paths = new HashSet<>();
        for (Entry e : r.files) {
            paths.add(e.path);
        }
        checkReferences(texts, paths, r, false);
        checkViewport(texts.get("index.html"), r);
        return r;
    }

    // ------------------------------------------------------- problem finding

    private static final Pattern VIEWPORT = Pattern.compile(
            "<meta[^>]+name\\s*=\\s*[\"']?viewport", Pattern.CASE_INSENSITIVE);

    private static void checkViewport(String html, Result r) {
        if (html != null && !VIEWPORT.matcher(html).find()) {
            r.warnings.add("Your main page has no viewport tag, so it may look tiny on a phone. "
                    + "Add this inside <head>: <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
        }
    }

    private static final class Ref {
        final String url;
        /** True when the page needs this file to display (image, script, style sheet). */
        final boolean resource;

        Ref(String url, boolean resource) {
            this.url = url;
            this.resource = resource;
        }
    }

    private static final Pattern HTML_COMMENT = Pattern.compile("<!--.*?-->", Pattern.DOTALL);
    private static final Pattern SCRIPT_BODY = Pattern.compile(
            "(<script\\b[^>]*>).*?</script\\s*>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
    private static final Pattern STYLE_BLOCK = Pattern.compile(
            "<style\\b[^>]*>(.*?)</style\\s*>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
    private static final Pattern TAG = Pattern.compile("<([a-zA-Z][a-zA-Z0-9]*)\\b([^>]*)>");
    private static final Pattern ATTR = Pattern.compile(
            "([a-zA-Z_:][-a-zA-Z0-9_:.]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s\"'=<>`]+))");
    private static final Pattern CSS_COMMENT = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
    private static final Pattern CSS_URL = Pattern.compile(
            "url\\(\\s*(['\"]?)([^'\")]*)\\1\\s*\\)", Pattern.CASE_INSENSITIVE);
    private static final Pattern CSS_IMPORT = Pattern.compile(
            "@import\\s+(['\"])([^'\"]+)\\1", Pattern.CASE_INSENSITIVE);
    private static final Pattern SCHEME = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.\\-]*:.*", Pattern.DOTALL);
    private static final Pattern WINDOWS_PATH = Pattern.compile("^[a-zA-Z]:[\\\\/].*", Pattern.DOTALL);

    private static List<Ref> cssRefs(String css) {
        List<Ref> out = new ArrayList<>();
        String s = CSS_COMMENT.matcher(css).replaceAll("");
        Matcher m = CSS_URL.matcher(s);
        while (m.find()) {
            out.add(new Ref(m.group(2).trim(), true));
        }
        Matcher im = CSS_IMPORT.matcher(s);
        while (im.find()) {
            out.add(new Ref(im.group(2).trim(), true));
        }
        return out;
    }

    private static List<Ref> htmlRefs(String html) {
        List<Ref> out = new ArrayList<>();
        String s = HTML_COMMENT.matcher(html).replaceAll("");
        Matcher sb = STYLE_BLOCK.matcher(s);
        while (sb.find()) {
            out.addAll(cssRefs(sb.group(1)));
        }
        s = SCRIPT_BODY.matcher(s).replaceAll("$1"); // keep <script src=...>, drop the code inside

        Matcher t = TAG.matcher(s);
        while (t.find()) {
            String tag = t.group(1).toLowerCase(Locale.ROOT);
            Map<String, String> attrs = new HashMap<>();
            Matcher a = ATTR.matcher(t.group(2));
            while (a.find()) {
                String value = a.group(2) != null ? a.group(2)
                        : a.group(3) != null ? a.group(3) : a.group(4);
                attrs.put(a.group(1).toLowerCase(Locale.ROOT), value);
            }
            for (String name : new String[]{"src", "poster", "data-src"}) {
                if (attrs.containsKey(name)) {
                    out.add(new Ref(attrs.get(name).trim(), true));
                }
            }
            String href = attrs.get("href");
            if (href != null && !tag.equals("base")) {
                boolean resource = false;
                if (tag.equals("link")) {
                    String rel = attrs.get("rel");
                    resource = rel != null && rel.toLowerCase(Locale.ROOT).contains("stylesheet");
                }
                out.add(new Ref(href.trim(), resource));
            }
        }
        return out;
    }

    private static void checkReferences(Map<String, String> texts, Set<String> allPaths,
                                        Result r, boolean singleFile) {
        Map<String, String> lowerIndex = new HashMap<>();
        for (String p : allPaths) {
            lowerIndex.put(p.toLowerCase(Locale.ROOT), p);
        }

        Map<String, String> missing = new LinkedHashMap<>(); // wanted path -> page that wants it
        Set<String> external = new LinkedHashSet<>();
        Set<String> onComputer = new LinkedHashSet<>();

        for (Map.Entry<String, String> e : texts.entrySet()) {
            String path = e.getKey();
            String dir = path.contains("/") ? path.substring(0, path.lastIndexOf('/') + 1) : "";
            List<Ref> refs = path.toLowerCase(Locale.ROOT).endsWith(".css")
                    ? cssRefs(e.getValue()) : htmlRefs(e.getValue());

            for (Ref ref : refs) {
                String url = ref.url;
                if (url.isEmpty() || url.startsWith("#")) {
                    continue;
                }
                String lower = url.toLowerCase(Locale.ROOT);
                if (lower.startsWith("file:") || WINDOWS_PATH.matcher(url).matches()) {
                    onComputer.add(url);
                    continue;
                }
                if (lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("//")) {
                    if (ref.resource) {
                        external.add(url);
                    }
                    continue;
                }
                if (SCHEME.matcher(url).matches()) {
                    continue; // mailto:, tel:, data:, javascript:, blob: ...
                }
                if (isPlaceholder(url)) {
                    continue;
                }

                String clean = url.replace('\\', '/');
                int cut = indexOfAny(clean, '?', '#');
                if (cut >= 0) {
                    clean = clean.substring(0, cut);
                }
                clean = decodeUrl(clean);
                String resolved = resolve(dir, clean);
                if (resolved == null) {
                    continue;
                }
                if (resolved.isEmpty() || resolved.endsWith("/")) {
                    resolved += "index.html";
                }
                if (allPaths.contains(resolved) || allPaths.contains(resolved + "/index.html")) {
                    continue;
                }
                if (!missing.containsKey(resolved)) {
                    missing.put(resolved, path);
                }
            }
        }

        int listed = 0;
        for (Map.Entry<String, String> m : missing.entrySet()) {
            if (listed == MAX_LISTED) {
                r.warnings.add("...and " + (missing.size() - MAX_LISTED) + " more missing files.");
                break;
            }
            String msg = "Missing file \"" + m.getKey() + "\" (used in " + m.getValue() + ").";
            String similar = lowerIndex.get(m.getKey().toLowerCase(Locale.ROOT));
            if (similar != null) {
                msg += " Did you mean \"" + similar + "\"? Android cares about capital and small letters.";
            }
            r.warnings.add(msg);
            listed++;
        }
        if (singleFile && !missing.isEmpty()) {
            r.warnings.add("To include images, style sheets and scripts, put everything in one .zip file.");
        }
        if (!external.isEmpty()) {
            String first = external.iterator().next();
            r.warnings.add(external.size() + " file(s) are loaded from the internet (for example " + first
                    + "). They will not work offline. Download them into your project folder.");
        }
        if (!onComputer.isEmpty()) {
            r.warnings.add("Your pages refer to files on your computer (for example "
                    + onComputer.iterator().next() + "). Use relative paths like images/logo.png instead.");
        }
    }

    private static boolean isPlaceholder(String url) {
        return url.contains("${") || url.contains("{{") || url.contains("<%") || url.contains("{%")
                || url.indexOf('\'') >= 0 || url.indexOf('"') >= 0 || url.indexOf('+') >= 0
                || url.indexOf('<') >= 0 || url.indexOf('>') >= 0;
    }

    /** Works out which file inside the project a link points to. Returns null if it leaves the project. */
    static String resolve(String dir, String ref) {
        String p = ref.startsWith("/") ? ref.substring(1) : dir + ref;
        boolean trailing = p.endsWith("/");
        List<String> out = new ArrayList<>();
        for (String part : p.split("/")) {
            if (part.isEmpty() || part.equals(".")) {
                continue;
            }
            if (part.equals("..")) {
                if (out.isEmpty()) {
                    return null;
                }
                out.remove(out.size() - 1);
            } else {
                out.add(part);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < out.size(); i++) {
            if (i > 0) {
                sb.append('/');
            }
            sb.append(out.get(i));
        }
        if (trailing && sb.length() > 0) {
            sb.append('/');
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- helpers

    private static String decodeUrl(String s) {
        try {
            return URLDecoder.decode(s.replace("+", "%2B"), "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static int indexOfAny(String s, char a, char b) {
        int best = -1;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == a || c == b) {
                best = i;
                break;
            }
        }
        return best;
    }

    private static boolean isSafeName(String name) {
        if (name.startsWith("/")) {
            return false;
        }
        for (String part : name.split("/")) {
            if (part.equals("..")) {
                return false;
            }
        }
        return true;
    }

    private static boolean isJunk(String name) {
        return name.startsWith("__MACOSX/") || name.contains("/__MACOSX/")
                || name.equals(".git") || name.startsWith(".git/") || name.contains("/.git/")
                || name.endsWith(".DS_Store") || name.endsWith("Thumbs.db");
    }

    private static String baseName(String name) {
        return name.substring(name.lastIndexOf('/') + 1);
    }

    private static int depth(String name) {
        int d = 0;
        for (int i = 0; i < name.length(); i++) {
            if (name.charAt(i) == '/') {
                d++;
            }
        }
        return d;
    }

    private static String decode(byte[] data) throws IOException {
        return data == null ? "" : new String(data, "UTF-8");
    }

    private static int readFully(InputStream in, byte[] buf) throws IOException {
        int total = 0;
        while (total < buf.length) {
            int n = in.read(buf, total, buf.length - total);
            if (n < 0) {
                break;
            }
            total += n;
        }
        return total;
    }

    /** Reads up to {@code limit} bytes. Returns null if the stream holds more than that. */
    private static byte[] readLimited(InputStream in, long limit) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        long total = 0;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > limit) {
                return null;
            }
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }
}
