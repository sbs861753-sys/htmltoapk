package com.htmltoapk.builder;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;

/**
 * The key used to sign every generated APK.
 *
 * Created once on first use and kept in the app's private storage. Android
 * only lets you update an installed app if the new version is signed with the
 * same key, so this key is reused for all builds on this device.
 */
final class SigningKey {

    final PrivateKey privateKey;
    final X509Certificate certificate;

    private SigningKey(PrivateKey privateKey, X509Certificate certificate) {
        this.privateKey = privateKey;
        this.certificate = certificate;
    }

    static SigningKey loadOrCreate(File dir) throws Exception {
        File keyFile = new File(dir, "key.pk8");
        File certFile = new File(dir, "cert.der");
        if (keyFile.exists() && certFile.exists()) {
            try {
                return load(keyFile, certFile);
            } catch (Exception broken) {
                // fall through and make a fresh key
            }
        }
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Cannot create " + dir);
        }
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(2048, new SecureRandom());
        KeyPair pair = gen.generateKeyPair();
        byte[] certDer = selfSignedCertificate(pair, "HtmlToApk");
        write(keyFile, pair.getPrivate().getEncoded());
        write(certFile, certDer);
        return load(keyFile, certFile);
    }

    private static SigningKey load(File keyFile, File certFile) throws Exception {
        PrivateKey key = KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(readAll(keyFile)));
        try (InputStream in = new ByteArrayInputStream(readAll(certFile))) {
            X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                    .generateCertificate(in);
            return new SigningKey(key, cert);
        }
    }

    // ---- minimal X.509 certificate writer (DER) ----

    private static final byte[] OID_SHA256_WITH_RSA =
            {0x2A, (byte) 0x86, 0x48, (byte) 0x86, (byte) 0xF7, 0x0D, 0x01, 0x01, 0x0B};
    private static final byte[] OID_COMMON_NAME = {0x55, 0x04, 0x03};

    static byte[] selfSignedCertificate(KeyPair pair, String commonName) throws Exception {
        byte[] serial = new byte[8];
        new SecureRandom().nextBytes(serial);
        serial[0] = (byte) ((serial[0] & 0x3F) | 0x40); // positive, no leading zero

        byte[] sigAlg = der(0x30, der(0x06, OID_SHA256_WITH_RSA), der(0x05, new byte[0]));
        byte[] name = der(0x30, der(0x31, der(0x30,
                der(0x06, OID_COMMON_NAME),
                der(0x0C, commonName.getBytes("UTF-8")))));
        byte[] validity = der(0x30,
                der(0x17, "200101000000Z".getBytes("US-ASCII")),
                der(0x17, "491231235959Z".getBytes("US-ASCII")));

        byte[] tbs = der(0x30,
                der(0xA0, der(0x02, new byte[]{2})), // version 3
                der(0x02, serial),
                sigAlg,
                name,
                validity,
                name,
                pair.getPublic().getEncoded()); // already a SubjectPublicKeyInfo

        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(pair.getPrivate());
        sig.update(tbs);
        byte[] signature = sig.sign();

        byte[] bitString = new byte[signature.length + 1]; // first byte = 0 unused bits
        System.arraycopy(signature, 0, bitString, 1, signature.length);

        return der(0x30, tbs, sigAlg, der(0x03, bitString));
    }

    private static byte[] der(int tag, byte[]... parts) throws IOException {
        int length = 0;
        for (byte[] p : parts) {
            length += p.length;
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        if (length < 0x80) {
            o.write(length);
        } else if (length < 0x100) {
            o.write(0x81);
            o.write(length);
        } else if (length < 0x10000) {
            o.write(0x82);
            o.write(length >> 8);
            o.write(length & 0xFF);
        } else {
            o.write(0x83);
            o.write(length >> 16);
            o.write((length >> 8) & 0xFF);
            o.write(length & 0xFF);
        }
        for (byte[] p : parts) {
            o.write(p);
        }
        return o.toByteArray();
    }

    private static byte[] readAll(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                o.write(buf, 0, n);
            }
            return o.toByteArray();
        }
    }

    private static void write(File f, byte[] data) throws IOException {
        try (OutputStream out = new FileOutputStream(f)) {
            out.write(data);
        }
    }
}
