package com.htmltoapk.builder;

/** Everything the person chooses on the screen for one app. */
final class BuildOptions {

    static final String TEMPLATE_PACKAGE = "com.template.webview";
    static final String BUILDER_PACKAGE = "com.htmltoapk.builder";

    static final String AUTO = "auto";
    static final String PORTRAIT = "portrait";
    static final String LANDSCAPE = "landscape";

    String appName = "";
    String packageName = "";
    String versionName = "1.0";
    String orientation = AUTO;
    boolean fullscreen;
    boolean keepScreenOn;
    boolean pullToRefresh;
    /** "#RRGGBB" or null for the default color. */
    String statusBarColor;

    // Each check returns a message for the person, or null when the value is fine.

    static String checkName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) {
            return "Type a name for your app";
        }
        if (n.length() > 50) {
            return "The name is too long (50 letters at most)";
        }
        for (int i = 0; i < n.length(); i++) {
            if (Character.isISOControl(n.charAt(i))) {
                return "The name cannot contain new lines";
            }
        }
        return null;
    }

    static String checkPackage(String pkg) {
        if (pkg == null || !pkg.matches("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+")) {
            return "Use a name like com.mycompany.myapp (small letters, numbers and dots)";
        }
        if (pkg.length() > 100) {
            return "The package name is too long";
        }
        if (pkg.equals(TEMPLATE_PACKAGE) || pkg.equals(BUILDER_PACKAGE)) {
            return "This package name is reserved. Choose another one";
        }
        if (pkg.startsWith("android.") || pkg.startsWith("com.android.")
                || pkg.startsWith("com.google.android.")) {
            return "Names starting with android are used by the system. Choose another one";
        }
        return null;
    }

    static String checkVersion(String v) {
        if (v == null || !v.matches("[0-9A-Za-z][0-9A-Za-z._+\\-]{0,29}")) {
            return "Use letters, numbers and dots, like 1.0 or 2.1.3";
        }
        return null;
    }

    /** Throws a BuildException with the first problem found. */
    void validate() throws BuildException {
        String e = checkName(appName);
        if (e == null) {
            e = checkPackage(packageName);
        }
        if (e == null) {
            e = checkVersion(versionName);
        }
        if (e == null && !(AUTO.equals(orientation) || PORTRAIT.equals(orientation)
                || LANDSCAPE.equals(orientation))) {
            e = "Unknown screen rotation setting";
        }
        if (e == null && statusBarColor != null && !statusBarColor.matches("#[0-9A-Fa-f]{6}")) {
            e = "Unknown status bar color";
        }
        if (e != null) {
            throw new BuildException(e);
        }
    }

    /** The settings file stored inside the generated app (assets/config.json). */
    String toConfigJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"orientation\":\"").append(orientation).append('"');
        sb.append(",\"fullscreen\":").append(fullscreen);
        sb.append(",\"keepScreenOn\":").append(keepScreenOn);
        sb.append(",\"pullToRefresh\":").append(pullToRefresh);
        if (statusBarColor != null) {
            sb.append(",\"statusBarColor\":\"").append(statusBarColor).append('"');
        }
        return sb.append('}').toString();
    }
}
